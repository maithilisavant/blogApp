import axios from "axios";

import {STORE_USER_DETAILS} from "../Reducers/types";

export const getUserDetails = (callback) => async (dispatch) => {
    //API call
    try{
        let data = await axios.get(`https://jsonplaceholder.typicode.com/users`);
        // console.log(data);
        dispatch({type: STORE_USER_DETAILS, payload: data.data});
        callback();
    }
    catch(e){
        console.log("Error",e);
    }
};

export const deleteUser = (data, index, cb) => async (dispatch) => {
    let currentData = data;
    currentData.splice(index, 1);
    dispatch({type: STORE_USER_DETAILS, payload: currentData});
    cb();
};

export const updateUser = (data, callback) => async (dispatch) => {
    dispatch({ type: STORE_USER_DETAILS, payload: data });
    callback();
};

export const addIsLike = (data, callback) => async (dispatch) => {
    dispatch({ type: STORE_USER_DETAILS, payload: data });
    callback();
}