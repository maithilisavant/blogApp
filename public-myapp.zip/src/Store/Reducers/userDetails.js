import { STORE_USER_DETAILS } from "./types";

const initialState = {
    userDetails: [],
};


export default function ( state = initialState, action){
    switch (action.type){
        case STORE_USER_DETAILS:
            return{
                userDetails: action.payload,
            };
        default:
            return state;
    }
}