import React, { Component } from "react";
import clsx from "clsx";
import { connect } from "react-redux";
import "./homescreen.css";
import UserCard from "../../Components/UserCard/index";
import { Grid } from "@material-ui/core";
import { getUserDetails, deleteUser, addIsLike } from "../../Store/Actions/actions";
import UserForm from "../../Components/Form";


class Homescreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userDetails: this.props.userDetails,
      showPopup: false,
      editData: undefined,
      editKey: 0,
    };
  }

  componentDidMount(){
    this.props.getUserDetails(()=>{ this.setState({userDetails: this.props.userDetails})})
  }

  // componentDidUpdate(previousProps, previousState){
  //   if(previousState.userDetails != this.props.userDetails){
  //     this.setState({userDetails: this.props.userDetails});
  //   }
  // }

  edit = (data) => {
    let index = this.props.userDetails.indexOf(data);
    this.setState({ editData: data, editKey: index, showPopup: true });
  };

  delete = (data) => {
    let index = this.state.userDetails.indexOf(data);
    this.props.deleteUser(this.props.userDetails, index, ()=>{
      this.setState({userDetails: this.props.userDetails })
    })
    
  };

  togglePopup = () => {
    this.setState({ showPopup: !this.state.showPopup });
  };

  addIsLike = (element) => {
    let index = this.state.userDetails.indexOf(element);
    let current = this.state.userDetails;
    current[index].isLike = true;
    
    this.props.addIsLike(current,
      ()=>{this.setState({
        userDetails: current,
      })}
    )
  }

  render() {
    const { showPopup } = this.state;
    return (
      this.state.userDetails.length === 0 ? <div>Loading...</div> :
      <>
      {showPopup && (
        <UserForm
          isPopupActive={showPopup}
          closePopup={this.togglePopup}
          editData={this.state.editData}
          editKey={this.state.editKey}
        />
      )}
      <div className="card-container">
          <Grid
            className="card-block"
            container
            rowSpacing={1}
            columnSpacing={{ xs: 1, sm: 2, md: 3 }}
          >
              {this.state.userDetails.map((element, index) => {
                  return (
                    <UserCard
                      data={element}
                      editData={() => {this.edit(element)}}
                      deleteData={() => {this.delete(element)}}
                      addIsLike = {() => {this.addIsLike(element)}}
                    />
                    
                  )
              })}
            
          </Grid>
      </div>
        
      </>
    )
  }
}

const mapStateToProps = (state) => {
    return {
      userDetails: state.userDetails.userDetails,
    };
  };
  
export default connect(mapStateToProps, 
    { 
      getUserDetails,
      deleteUser,
      addIsLike,
    }
)(Homescreen);