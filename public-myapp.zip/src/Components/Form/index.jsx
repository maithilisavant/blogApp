import React, { Component } from "react";
import Slide from "@material-ui/core/Slide";
import {
  Button,
  Grid,
  InputBase,
  TextField
} from "@material-ui/core";
import { connect } from "react-redux";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import { getUserDetails, deleteUser, updateUser } from "../../Store/Actions/actions";
import "./form.css";


const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="bottom" ref={ref} {...props} />;
});

class UserForm extends Component {
    constructor(props){
        super(props);
        this.state = {
            name:"",
            email:"",
            phone:"",
            website:"",

            isEdit: false,
            editKey: 0,
        }
    }

    componentDidMount() {
        //Check if edit mode is enabled
        if (this.props.editData) {
            let data = this.props.editData;
            let editKey = this.props.editKey;
            
            this.setState({
                isEdit: true,
                editKey: editKey,

                name: data.name,
                email: data.email,
                phone: data.phone,
                website: data.website,
            });
        }
    }
    saveFormData = () => {
        let userData = {
            name: this.state.name,
            email: this.state.email,
            phone: this.state.phone,
            website: this.state.website
        };

        let reducerData = this.props.userDetails;

        if (this.state.isEdit) {
            reducerData[this.state.editKey] = userData;
            this.props.updateUser(reducerData, this.props.closePopup);
        }
    };

    clearFormField = () => {
        this.setState({
          name: "",
          email: "",
          website: "",
          phone: "",
          isEdit: false,
          editKey: 0,
        });
    };

    onChangeHandler = (e, type) => {
        //Dynamic state setting
        this.setState({ [type]: e.target.value });
    };
    

    render() {
        const { isPopupActive, closePopup } = this.props;
        return (
            <>
                <Dialog
                    open={isPopupActive}
                    TransitionComponent={Transition}
                    fullWidth
                    maxWidth="md">
                    <DialogTitle>Edit User Info</DialogTitle>
                    <DialogContent>
                        <Grid container direction="column" className={"dialog-container"}>
                            <Grid item lg={6} xl={6} sm={6} xs={12}>
                                <Grid container direction="column">
                                    <Grid item>
                                        <div className="common-label">
                                            Name
                                            <span style={{ color: "red" }}>*</span>
                                        </div>
                                    </Grid>
                                    <Grid item>
                                        <TextField
                                            className="input"
                                            placeholder={"Enter Name"}
                                            value={this.state.name}
                                            autoComplete={"off"}
                                            onChange={(e) => {
                                                this.onChangeHandler(e, "name");
                                            }}
                                        ></TextField>
                                    </Grid>

                                    <Grid item>
                                        <div className="common-label">
                                            Email
                                            <span style={{ color: "red" }}>*</span>
                                        </div>
                                    </Grid>
                                    <Grid item>
                                        <TextField
                                            className="input"
                                            placeholder={"Enter Email"}
                                            value={this.state.email}
                                            onChange={(e) => {
                                                this.onChangeHandler(e, "email");
                                            }}
                                        ></TextField>
                                    </Grid>

                                    <Grid item>
                                        <div className="common-label">
                                            Phone
                                            <span style={{ color: "red" }}>*</span>
                                        </div>
                                    </Grid>
                                    <Grid item>
                                        <TextField
                                            className="input"
                                            placeholder={"Enter Phone"}
                                            value={this.state.phone}
                                            onChange={(e) => {
                                                this.onChangeHandler(e, "phone");
                                            }}
                                        ></TextField>
                                    </Grid>
                                    <Grid item>
                                        <div className="common-label">
                                            Website
                                            <span style={{ color: "red" }}>*</span>
                                        </div>
                                    </Grid>
                                    <Grid item>
                                        <TextField
                                            className="input"
                                            placeholder={"Enter Website"}
                                            value={this.state.website}
                                            onChange={(e) => {
                                                this.onChangeHandler(e, "website");
                                            }}
                                        ></TextField>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>
                    </DialogContent>
                    <DialogActions className="form-button-container">
                    <Button
                        className="form-button"
                        onClick={this.saveFormData}
                    >
                        OK
                    </Button>
                    <Button
                        className="form-button"
                        onClick={this.props.closePopup}
                    >
                        Cancel
                    </Button>
                    </DialogActions>
                </Dialog>
            </>
        )
    }
}

const mapStateToProps = (state) => {
    return {
      userDetails: state.userDetails.userDetails,
    };
  };
  
export default connect(mapStateToProps, 
    { 
      getUserDetails,
      deleteUser,
      updateUser,
    }
)(UserForm);