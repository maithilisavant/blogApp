//Functional Component
import React from "react";
import "./usercard.css";
import {EditOutlined, FavoriteBorder, Favorite, DeleteOutline, MailOutline, PhoneOutlined, LanguageOutlined} from "@material-ui/icons"
import { IconButton } from "@material-ui/core";

function UserCard(props) {
  return (
    <>
      <div className="container">
        <div className="user-profile">
          <img src="https://avatars.dicebear.com/v2/avataaars/{{username}}.svg?options[mood][]=happy" className="profile-image"></img>
        </div>
        <div>
            <div className="user-name data">{props.data.name}</div>

            <div className="email-block data details">
                <MailOutline></MailOutline>
                <div className="user-email">{props.data.email}</div>
            </div>

            <div className="phone-block data details">
                <PhoneOutlined></PhoneOutlined>
                <div className="user-phone">{props.data.phone}</div>
            </div>

            <div className="website-block data details">
                <LanguageOutlined></LanguageOutlined>
                <div className="website">{props.data.website}</div>
            </div>
        </div>
        <div className="block1">
            <div className="block2">
              <IconButton>
                <Favorite onClick={() => props.addIsLike()}
                  style={{color: props.data.isLike === true ? "red" : "none"}}
                  className="like" />
              </IconButton>
            </div>
            <div className="block2"><IconButton><EditOutlined className="icon" onClick={() => props.editData()}/></IconButton></div>
            <div className="block2"><IconButton><DeleteOutline className="icon" onClick={() => props.deleteData()}/></IconButton></div>
        </div>
      </div>
    </>
  );
}

export default UserCard;